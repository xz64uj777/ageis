# AegisScan Native Android

AegisScan is a native Android security monitor. Version 4 replaces the previous WebView/HTML shell with Kotlin-based device checks and a native dashboard.

## Current checks

- Root indicators (best-effort)
- Debugger attachment
- Emulator indicators
- Developer options
- USB debugging / ADB setting
- Network connectivity and transport
- Security score and threat indicator count

## Build

Use Android Studio or AndroidIDE with JDK 17 and Android SDK 35. The GitHub Actions workflow also builds a debug APK and stores it as an artifact.

## Important limitations

A security scan can report indicators; it cannot prove that a device is perfectly secure. Root detection in particular is heuristic and can produce false positives/negatives.
