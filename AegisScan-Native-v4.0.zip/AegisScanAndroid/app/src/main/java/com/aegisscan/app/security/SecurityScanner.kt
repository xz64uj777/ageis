package com.aegisscan.app.security

import android.content.Context
import com.aegisscan.app.model.ScanCheck
import com.aegisscan.app.model.ScanResult
import com.aegisscan.app.model.Severity

object SecurityScanner {
    fun scan(context: Context): ScanResult {
        val checks = mutableListOf<ScanCheck>()
        val rooted = RootDetector.isLikelyRooted()
        checks += ScanCheck(
            "Root indicators",
            RootDetector.detail(),
            rooted,
            if (rooted) Severity.CRITICAL else Severity.INFO
        )

        val debugger = DebuggerDetector.isDebuggerConnected()
        checks += ScanCheck(
            "Debugger",
            DebuggerDetector.detail(),
            debugger,
            if (debugger) Severity.CRITICAL else Severity.INFO
        )

        val emulator = EmulatorDetector.isLikelyEmulator()
        checks += ScanCheck(
            "Emulator profile",
            EmulatorDetector.detail(),
            emulator,
            Severity.WARNING
        )

        val dev = DeveloperOptionsDetector.isEnabled(context)
        checks += ScanCheck(
            "Developer options",
            DeveloperOptionsDetector.detail(context),
            dev,
            Severity.WARNING
        )

        val adb = UsbDebuggingDetector.isEnabled(context)
        checks += ScanCheck(
            "USB debugging",
            UsbDebuggingDetector.detail(context),
            adb,
            Severity.WARNING
        )

        val network = NetworkDetector.isConnected(context)
        checks += ScanCheck(
            "Network",
            if (network) "Connected via ${NetworkDetector.transport(context)}." else "No active internet connection detected.",
            false,
            Severity.INFO
        )

        val deductions = checks.sumOf {
            when (it.severity) {
                Severity.CRITICAL -> 25
                Severity.WARNING -> if (it.name == "Emulator profile") 8 else 10
                Severity.INFO -> 0
            }
        }
        val score = (100 - deductions).coerceIn(0, 100)
        return ScanResult(checks, score, System.currentTimeMillis())
    }
}
