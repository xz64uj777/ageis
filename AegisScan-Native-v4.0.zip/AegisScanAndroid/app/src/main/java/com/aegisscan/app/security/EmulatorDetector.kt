package com.aegisscan.app.security

import android.os.Build

object EmulatorDetector {
    fun isLikelyEmulator(): Boolean {
        val fingerprint = Build.FINGERPRINT.orEmpty().lowercase()
        val model = Build.MODEL.orEmpty().lowercase()
        val manufacturer = Build.MANUFACTURER.orEmpty().lowercase()
        val brand = Build.BRAND.orEmpty().lowercase()
        val product = Build.PRODUCT.orEmpty().lowercase()

        return fingerprint.startsWith("generic") ||
            fingerprint.contains("emulator") ||
            fingerprint.contains("test-keys") && (model.contains("sdk") || model.contains("emulator")) ||
            model.contains("google_sdk") ||
            model.contains("emulator") ||
            manufacturer.contains("genymotion") ||
            (brand.startsWith("generic") && product.startsWith("generic"))
    }

    fun detail(): String = if (isLikelyEmulator()) {
        "The device profile matches common emulator indicators."
    } else {
        "No common emulator indicators were detected."
    }
}
