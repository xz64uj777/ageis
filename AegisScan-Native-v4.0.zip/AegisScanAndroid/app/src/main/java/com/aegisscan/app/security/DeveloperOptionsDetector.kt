package com.aegisscan.app.security

import android.content.Context
import android.provider.Settings

object DeveloperOptionsDetector {
    fun isEnabled(context: Context): Boolean = runCatching {
        Settings.Global.getInt(context.contentResolver, Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1
    }.getOrDefault(false)

    fun detail(context: Context): String = if (isEnabled(context)) {
        "Developer options are enabled."
    } else {
        "Developer options are disabled."
    }
}
