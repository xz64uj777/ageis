package com.aegisscan.app.security

import android.os.Build
import java.io.File

object RootDetector {
    private val suPaths = listOf(
        "/system/bin/su", "/system/xbin/su", "/sbin/su",
        "/system/su", "/system/bin/.ext/su", "/system/usr/we-need-root/su",
        "/vendor/bin/su", "/cache/su", "/data/local/su", "/data/local/bin/su", "/data/local/xbin/su"
    )

    fun isLikelyRooted(): Boolean {
        val hasSu = suPaths.any { File(it).exists() }
        val testKeys = arrayOf("ro.debuggable", "ro.secure", "ro.build.tags")
        val propRisk = testKeys.any { key ->
            runCatching { getSystemProperty(key) }.getOrNull()?.let { value ->
                when (key) {
                    "ro.debuggable" -> value == "1"
                    "ro.secure" -> value == "0"
                    "ro.build.tags" -> value.contains("test-keys")
                    else -> false
                }
            } == true
        }
        return hasSu || propRisk
    }

    fun detail(): String = when {
        Build.TAGS?.contains("test-keys") == true -> "Test-key build detected; this can indicate a modified build."
        suPaths.any { File(it).exists() } -> "A known su binary location was found."
        else -> "No common root indicators were found. This does not prove the device is unrooted."
    }

    private fun getSystemProperty(name: String): String? = runCatching {
        val process = Runtime.getRuntime().exec(arrayOf("/system/bin/getprop", name))
        process.inputStream.bufferedReader().use { it.readLine()?.trim() }
    }.getOrNull()
}
