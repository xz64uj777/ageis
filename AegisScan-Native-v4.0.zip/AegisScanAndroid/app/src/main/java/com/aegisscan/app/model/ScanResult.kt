package com.aegisscan.app.model

data class ScanCheck(
    val name: String,
    val detail: String,
    val risky: Boolean,
    val severity: Severity = if (risky) Severity.WARNING else Severity.INFO
)

enum class Severity { INFO, WARNING, CRITICAL }

data class ScanResult(
    val checks: List<ScanCheck>,
    val score: Int,
    val timestamp: Long
) {
    val threatCount: Int get() = checks.count { it.risky }
}
