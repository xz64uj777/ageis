package com.aegisscan.app

import android.os.Bundle
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.aegisscan.app.model.ScanResult
import com.aegisscan.app.model.Severity
import com.aegisscan.app.security.SecurityScanner
import java.text.DateFormat
import java.util.Date

class MainActivity : AppCompatActivity() {
    private lateinit var scoreView: TextView
    private lateinit var statusView: TextView
    private lateinit var threatsView: TextView
    private lateinit var checksContainer: LinearLayout
    private lateinit var rootContainer: LinearLayout
    private lateinit var lastScanView: TextView
    private var lastResult: ScanResult? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        runScan()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF070B14.toInt())
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(28))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(12))
        }
        header.addView(text("AEGISSCAN", 12f, 0xFFF43F5E.toInt(), true))
        header.addView(text("Android Security Monitor", 28f, 0xFFFFFFFF.toInt(), true).apply { setPadding(0, dp(4), 0, 0) })
        header.addView(text("Native device checks — no WebView", 13f, 0xFFAAB4C3.toInt()).apply { setPadding(0, dp(6), 0, 0) })
        content.addView(header)

        val scoreCard = card()
        scoreCard.addView(text("SECURITY SCORE", 12f, 0xFFAAB4C3.toInt(), true))
        scoreView = text("--", 52f, 0xFFFFFFFF.toInt(), true).apply { gravity = Gravity.CENTER_HORIZONTAL; setPadding(0, dp(8), 0, 0) }
        scoreCard.addView(scoreView)
        statusView = text("Scanning…", 14f, 0xFFAAB4C3.toInt(), true).apply { gravity = Gravity.CENTER_HORIZONTAL; setPadding(0, dp(4), 0, dp(4)) }
        scoreCard.addView(statusView)
        content.addView(scoreCard)

        val actionCard = card()
        val scanButton = android.widget.Button(this).apply {
            text = "RUN SECURITY SCAN"
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFFF43F5E.toInt())
            setOnClickListener { runScan() }
        }
        actionCard.addView(scanButton, LinearLayout.LayoutParams(-1, dp(52)))
        content.addView(actionCard)

        threatsView = text("Threats: 0", 16f, 0xFFFFFFFF.toInt(), true).apply { setPadding(dp(4), dp(14), 0, dp(8)) }
        content.addView(threatsView)

        checksContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(checksContainer)

        lastScanView = text("Last scan: --", 12f, 0xFF7F899A.toInt()).apply { setPadding(0, dp(18), 0, 0) }
        content.addView(lastScanView)

        val scroll = ScrollView(this).apply { addView(content) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun runScan() {
        statusView.text = "Scanning device…"
        val start = SystemClock.elapsedRealtime()
        val result = SecurityScanner.scan(this)
        val elapsed = SystemClock.elapsedRealtime() - start
        lastResult = result
        render(result, elapsed)
    }

    private fun render(result: ScanResult, elapsedMs: Long) {
        scoreView.text = result.score.toString()
        statusView.text = when {
            result.score >= 90 -> "LOW RISK • completed in ${elapsedMs}ms"
            result.score >= 70 -> "REVIEW RECOMMENDED • completed in ${elapsedMs}ms"
            else -> "HIGH RISK • completed in ${elapsedMs}ms"
        }
        threatsView.text = "Threat indicators: ${result.threatCount}"
        checksContainer.removeAllViews()

        result.checks.forEach { check ->
            val item = card()
            val title = text(check.name, 16f, 0xFFFFFFFF.toInt(), true)
            val detail = text(check.detail, 13f, 0xFFAAB4C3.toInt()).apply { setPadding(0, dp(6), 0, 0) }
            val state = when (check.severity) {
                Severity.CRITICAL -> "CRITICAL"
                Severity.WARNING -> "REVIEW"
                Severity.INFO -> "OK"
            }
            val stateView = text(state, 11f, if (check.risky) 0xFFF43F5E.toInt() else 0xFF55D6BE.toInt(), true).apply { setPadding(0, dp(10), 0, 0) }
            item.addView(title)
            item.addView(detail)
            item.addView(stateView)
            checksContainer.addView(item)
        }

        lastScanView.text = "Last scan: ${DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(result.timestamp))}"
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        setBackgroundColor(0xFF111827.toInt())
        val lp = LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, 0, 0, dp(12))
        layoutParams = lp
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
