package com.aegisscan.app.security

import android.os.Debug

object DebuggerDetector {
    fun isDebuggerConnected(): Boolean = Debug.isDebuggerConnected()
    fun detail(): String = if (isDebuggerConnected()) {
        "A debugger is currently attached to the application."
    } else {
        "No debugger is currently attached."
    }
}
