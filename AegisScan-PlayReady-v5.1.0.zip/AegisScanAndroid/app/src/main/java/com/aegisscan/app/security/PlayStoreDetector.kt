package com.aegisscan.app.security

import android.content.Context

object PlayStoreDetector {
    fun isProbablyPlayInstalled(context: Context): Boolean =
        InstallSourceDetector.sourcePackage(context) == "com.android.vending"
}
