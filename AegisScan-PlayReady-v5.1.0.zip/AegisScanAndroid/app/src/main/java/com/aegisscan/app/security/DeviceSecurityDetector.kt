package com.aegisscan.app.security

import android.app.KeyguardManager
import android.content.Context
import android.os.Build
import android.os.PowerManager
import android.os.storage.StorageManager

object DeviceSecurityDetector {
    data class Result(val risky: Boolean, val detail: String, val evidence: String)

    fun lockScreen(context: Context): Result {
        val km = context.getSystemService(KeyguardManager::class.java)
            ?: return Result(false, "Lock-screen state could not be determined.", "KeyguardManager unavailable")
        return if (km.isDeviceSecure) {
            Result(false, "A secure lock screen is configured.", "KeyguardManager.isDeviceSecure=true")
        } else {
            Result(true, "No secure lock screen is configured. Use a PIN, password, or supported secure biometric/pattern setup.", "KeyguardManager.isDeviceSecure=false")
        }
    }

    fun encryption(context: Context): Result {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            return Result(false, "Storage encryption state is not checked on this Android version.", "API < 24")
        }
        val storage = context.getSystemService(StorageManager::class.java)
            ?: return Result(false, "Storage encryption state could not be determined.", "StorageManager unavailable")
        @Suppress("DEPRECATION")
        val encrypted = runCatching { storage.isEncrypted(context.dataDir) }.getOrNull()
        return when (encrypted) {
            true -> Result(false, "Android reports encrypted storage.", "StorageManager.isEncrypted=true")
            false -> Result(true, "Android does not report encrypted storage.", "StorageManager.isEncrypted=false")
            null -> Result(false, "Storage encryption state could not be determined.", "StorageManager.isEncrypted unavailable")
        }
    }

    fun powerSaver(context: Context): Result {
        val pm = context.getSystemService(PowerManager::class.java)
            ?: return Result(false, "Power-saver state could not be determined.", "PowerManager unavailable")
        val on = runCatching { pm.isPowerSaveMode }.getOrDefault(false)
        return Result(false, if (on) "Battery saver is currently enabled." else "Battery saver is currently disabled.", "PowerManager.isPowerSaveMode=$on")
    }
}
