package com.aegisscan.app.security

import android.content.Context
import android.os.Build

object InstallSourceDetector {
    fun sourcePackage(context: Context, packageName: String = context.packageName): String? {
        if (Build.VERSION.SDK_INT < 30) return null
        return runCatching {
            context.packageManager.getInstallSourceInfo(packageName).installingPackageName
        }.getOrNull()
    }

    fun detail(context: Context): String {
        val source = sourcePackage(context)
        return when (source) {
            "com.android.vending" -> "Installed by Google Play."
            null, "" -> "Install source could not be determined."
            else -> "Android reports installing package: $source"
        }
    }
}
