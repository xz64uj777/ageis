# AegisScan 5.1.1

# AegisScan

A native Kotlin Android security-posture monitor.

## What it is
AegisScan reports observable Android security signals and explains the evidence behind them. The numerical score describes **local security posture** only.

It is not an antivirus, malware detector, spyware detector, packet-inspection firewall, remote-hacker attribution tool, or proof of hardware/device integrity.

## Device posture checks
- Root indicators (heuristic)
- Debugger attachment to AegisScan
- USB/ADB debugging
- Developer options (review signal)
- Emulator indicators (review signal)
- Secure lock screen
- Encryption posture note (AegisScan does not claim to attest encryption state where Android does not expose a stable public API)
- Network transport / VPN / validated state
- Android version and security patch level
- AegisScan signing certificate SHA-256
- AegisScan install source
- AegisScan build debuggability

## Optional app risk audit
The user can explicitly run a local App Risk Audit. It inspects application information that Android makes visible to AegisScan and surfaces review signals such as sensitive permission requests, enabled accessibility services, overlay capability, debuggable builds, and unusual install sources.

A review signal is **not** a malware verdict.

This release intentionally does **not** request `QUERY_ALL_PACKAGES`. Android 11+ may therefore provide only a limited app inventory. Broad visibility should only be added after a specific Google Play policy assessment.

## Privacy
- No `INTERNET` permission.
- No analytics or advertising SDK.
- No account system.
- No remote scan-result upload.
- App-audit results are processed locally.

See `PRIVACY.md`, `DATA_SAFETY.md`, `SCORING.md`, and `PLAY_STORE_READINESS.md`.

## Build
- compileSdk 36
- targetSdk 36
- minSdk 26
- Java/Kotlin target 17
- Android Gradle Plugin 8.10.1
- Gradle 8.11.1

GitHub Actions installs the pinned Gradle version, runs unit tests and lint, builds a debug APK, and builds an unsigned release AAB. Configure the documented signing secrets to produce a signed release AAB.
