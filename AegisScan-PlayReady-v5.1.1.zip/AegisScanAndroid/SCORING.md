# AegisScan scoring methodology

The displayed score is a **local security posture score**, not a probability of compromise and not a malware-detection percentage.

## Deductions

- Known `su` executable in a standard location: **-35** (strong local root indicator)
- Debugger attached to AegisScan: **-20**
- USB debugging/ADB enabled: **-10**
- No secure lock screen: **-15**
- Android reports app data is not encrypted: **-15**
- AegisScan build is debuggable: **-10**

The score is clamped to 0–100.

## Review-only signals

These do **not** reduce the score because they can be legitimate and are not direct proof of compromise:

- Developer options enabled
- Emulator indicators
- Non-Play install source for AegisScan
- Visible applications with sensitive permission requests
- Enabled accessibility services
- Applications requesting overlay capability
- Applications marked debuggable
- Unusual application install sources
- VPN or other network context

## Why this matters

A security monitor should distinguish between an observable configuration, a suspicious signal, and a confirmed threat. AegisScan deliberately does not collapse those categories into a single “hacked/not hacked” claim.
