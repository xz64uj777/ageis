# Building AegisScan

## GitHub Actions
Push the project to the repository's `main` branch. The `Android CI` workflow will:

1. Install Gradle 8.11.1 and Java 17.
2. Run unit tests.
3. Run Android lint.
4. Build a debug APK.
5. Build an unsigned release AAB when signing secrets are not configured.

The generated APK/AAB files are published as workflow artifacts.

## AndroidIDE
Open this directory as an existing Gradle project. If AndroidIDE asks to create or regenerate the Gradle wrapper, allow it. The repository workflow does not require a committed wrapper because CI installs the pinned Gradle version directly.

## Production signing
Do not commit a keystore. For GitHub Actions, configure:

- `AEGIS_KEYSTORE_BASE64`
- `AEGIS_KEY_ALIAS`
- `AEGIS_KEY_PASSWORD`
- `AEGIS_STORE_PASSWORD`

The workflow will create a signed release AAB only when the keystore secret is present.
