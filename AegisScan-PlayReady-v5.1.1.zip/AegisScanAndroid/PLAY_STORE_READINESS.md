# AegisScan 5.1.1

# AegisScan Play Store readiness

## What the current app actually does
- Native Kotlin Android app; no WebView.
- Local device-security posture checks.
- Heuristic root-indicator checks; no claim of proving a device is unrooted.
- Debugger attachment check for the AegisScan process.
- ADB/USB debugging state.
- Developer-options and emulator-profile context signals.
- Secure lock-screen check.
- Encryption posture note; the app avoids claiming a device-wide encryption attestation where a stable public API is not available.
- Current network transport/VPN/validated state; no packet capture or traffic inspection.
- AegisScan install-source information.
- Optional visible-app audit for sensitive permissions, enabled accessibility services, overlay capability, debug flags, and unusual install sources.
- Local shareable report.
- No network permission, analytics SDK, ad SDK, account system, or remote scan-result upload.

## Deliberately NOT claimed
AegisScan is not currently an antivirus, malware detector, spyware detector, packet-inspection firewall, remote-hacker attribution tool, or proof of device integrity.

Play Integrity is not claimed. A proper Play Integrity implementation requires Google's documented token-verification flow and, where appropriate, a backend.

## Installed-app visibility
The current version intentionally does **not** request `QUERY_ALL_PACKAGES`. Android 11+ may therefore expose only a subset of installed packages to the app. This is intentional for privacy and Play-policy safety.

Google Play treats the installed-app inventory as personal and sensitive information and restricts broad visibility. If a future version needs `QUERY_ALL_PACKAGES`, the core user-facing purpose must justify broad visibility, the declaration must be completed in Play Console, and the app should explain the need prominently. Do not add the permission merely to make the scanner's results look more complete.

## Release requirements still outstanding
- Generate a production signing key and keep it outside source control.
- Configure the GitHub Actions signing secrets if automated signed AAB builds are desired.
- Test the signed AAB on multiple physical devices.
- Complete the Play Console Data Safety form from the final signed build.
- Publish a final privacy-policy URL matching the shipped behavior.
- Prepare store listing assets and an accurate description.
- Complete any required permissions declarations.
- Run Play pre-launch testing and review warnings before production rollout.

## Current target
The app targets API 36, matching Google Play's August 31, 2026 target-API requirement for new apps and updates.
