# AegisScan Privacy Notice (development draft)

AegisScan is designed to perform device-security posture checks locally on the user's Android device.

## Data accessed locally
The app reads Android-provided security and device-state information needed for the displayed checks. The optional App Risk Audit may inspect application package information that Android makes visible to AegisScan, including package names, requested permissions, debug flags, accessibility-service state, and install-source metadata.

## What the current version does not do
- It does not request microphone, camera, contacts, SMS, phone, location, accessibility control, or notification access for itself.
- It does not request internet access.
- It does not upload scan results to an AegisScan server.
- It does not sell or share installed-app information for ads or analytics.
- It does not run packet capture or inspect network traffic contents.

## App audit disclosure
The App Risk Audit is optional. Before running it, AegisScan explains that it will inspect application information Android makes visible to the app. The results are processed locally and are not transmitted by the current implementation.

## Important accuracy limitation
AegisScan reports observable signals, not certainty. A missing signal does not prove that a device or application is safe. A review signal does not prove that an application is malicious.

This is a development draft and must be reviewed against the final signed build before publication.
