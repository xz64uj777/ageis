# AegisScan changelog

## 5.1.1

- Removed the CI dependency on a committed Gradle wrapper; GitHub Actions installs Gradle 8.11.1 directly.
- Added AndroidIDE build guidance.
- Moved the device scan off the UI thread.
- Reworked encryption reporting so the app does not claim a device-wide encryption attestation that Android's stable public APIs do not consistently provide.
- Fixed install-source scoring on Android versions where the source API is unavailable; unknown is now informational rather than a false review finding.
- Kept `QUERY_ALL_PACKAGES` out of the manifest pending a deliberate Google Play package-visibility decision.
- Bumped versionCode to 52 and versionName to 5.1.1.
