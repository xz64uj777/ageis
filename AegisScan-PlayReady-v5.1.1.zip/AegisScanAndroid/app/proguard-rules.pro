# AegisScan has no reflection-based security bridge or WebView bridge.
# Keep this file for future release-specific shrinker rules.
