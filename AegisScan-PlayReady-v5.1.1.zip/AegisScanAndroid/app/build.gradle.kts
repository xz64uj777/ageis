plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.aegisscan.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.aegisscan.app"
        minSdk = 26
        targetSdk = 36
        versionCode = 52
        versionName = "5.1.1"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        debug {
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
            isDebuggable = true
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    // Optional release signing. Local builds remain unsigned unless the values are supplied.
    val keystorePath = System.getenv("AEGIS_KEYSTORE_PATH")
    val keyAliasEnv = System.getenv("AEGIS_KEY_ALIAS")
    val keyPasswordEnv = System.getenv("AEGIS_KEY_PASSWORD")
    val storePasswordEnv = System.getenv("AEGIS_STORE_PASSWORD")
    if (!keystorePath.isNullOrBlank() && !keyAliasEnv.isNullOrBlank() &&
        !keyPasswordEnv.isNullOrBlank() && !storePasswordEnv.isNullOrBlank()) {
        signingConfigs {
            create("release") {
                storeFile = file(keystorePath)
                keyAlias = keyAliasEnv
                keyPassword = keyPasswordEnv
                storePassword = storePasswordEnv
            }
        }
        buildTypes.getByName("release").signingConfig = signingConfigs.getByName("release")
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.16.0")
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("com.google.android.material:material:1.13.0")
    testImplementation("junit:junit:4.13.2")
}
