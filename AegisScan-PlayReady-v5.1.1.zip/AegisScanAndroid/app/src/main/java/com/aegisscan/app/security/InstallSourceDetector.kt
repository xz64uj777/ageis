package com.aegisscan.app.security

import android.content.Context
import android.os.Build

object InstallSourceDetector {
    fun sourcePackage(context: Context, packageName: String = context.packageName): String? {
        if (Build.VERSION.SDK_INT < 30) return null
        return runCatching {
            context.packageManager.getInstallSourceInfo(packageName).installingPackageName
        }.getOrNull()
    }

    fun isProbablyPlayInstalled(context: Context): Boolean? {
        if (Build.VERSION.SDK_INT < 30) return null
        return sourcePackage(context) == "com.android.vending"
    }

    fun detail(context: Context): String {
        return when (val source = sourcePackage(context)) {
            "com.android.vending" -> "Android reports Google Play as the installing package."
            null, "" -> if (Build.VERSION.SDK_INT < 30) {
                "Install source is not exposed by the API used on this Android version."
            } else {
                "Install source could not be determined."
            }
            else -> "Android reports installing package: $source"
        }
    }
}
