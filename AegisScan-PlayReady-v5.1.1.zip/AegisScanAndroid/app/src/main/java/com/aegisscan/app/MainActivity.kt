package com.aegisscan.app

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.aegisscan.app.model.AppRisk
import com.aegisscan.app.model.ScanResult
import com.aegisscan.app.model.Severity
import com.aegisscan.app.security.SecurityScanner
import java.text.DateFormat
import java.util.Date
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var scoreView: TextView
    private lateinit var postureView: TextView
    private lateinit var summaryView: TextView
    private lateinit var checksContainer: LinearLayout
    private lateinit var appAuditContainer: LinearLayout
    private lateinit var appAuditSummary: TextView
    private lateinit var lastScanView: TextView
    private var latest: ScanResult? = null
    private val auditExecutor = Executors.newSingleThreadExecutor()
    private val scanExecutor = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        runScan()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF070B14.toInt())
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(30))
        }

        content.addView(label("AEGISSCAN"))
        content.addView(title("Android Security Monitor"))
        content.addView(body("A local security-posture monitor. Results are based on observable Android signals and are not proof that a device is malware-free or uncompromised."))

        val scoreCard = card()
        scoreCard.addView(label("LOCAL SECURITY POSTURE"))
        scoreView = title("--").apply {
            textSize = 52f
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, dp(8), 0, 0)
        }
        scoreCard.addView(scoreView)
        postureView = body("Scanning…").apply {
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, dp(2), 0, dp(4))
        }
        scoreCard.addView(postureView)
        content.addView(scoreCard)

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val scanButton = Button(this).apply {
            text = "SCAN DEVICE"
            isAllCaps = false
            setOnClickListener { runScan() }
        }
        actions.addView(scanButton, LinearLayout.LayoutParams(0, dp(52), 1f).apply {
            setMargins(0, 0, dp(6), dp(12))
        })
        val shareButton = Button(this).apply {
            text = "SHARE REPORT"
            isAllCaps = false
            setOnClickListener { shareReport() }
        }
        actions.addView(shareButton, LinearLayout.LayoutParams(0, dp(52), 1f).apply {
            setMargins(dp(6), 0, 0, dp(12))
        })
        content.addView(actions)

        summaryView = body("Risk indicators: 0")
        content.addView(summaryView)

        val scopeCard = card()
        scopeCard.addView(label("WHAT THIS SCAN CAN ACTUALLY TELL YOU"))
        scopeCard.addView(body("AegisScan checks local posture signals such as root indicators, debugger attachment, ADB, lock-screen security, storage encryption, developer options, emulator indicators, build state, install source, and network transport."))
        scopeCard.addView(body("It does not currently perform antivirus scanning, spyware detection, packet inspection, remote-hacker attribution, or hardware-backed Play Integrity verification."))
        content.addView(scopeCard)

        checksContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(checksContainer)

        val auditCard = card()
        auditCard.addView(label("APP RISK AUDIT"))
        auditCard.addView(body("This optional audit inspects the application inventory Android makes visible to AegisScan. It looks for review signals such as sensitive permissions, enabled accessibility services, overlay capability, debuggable builds, and unusual install sources. It does not call an app malicious just because a signal exists."))
        appAuditSummary = body("Not run yet.")
        auditCard.addView(appAuditSummary.apply { setPadding(0, dp(8), 0, dp(8)) })
        val auditButton = Button(this).apply {
            text = "RUN APP AUDIT"
            isAllCaps = false
            setOnClickListener { runAppAuditWithDisclosure() }
        }
        auditCard.addView(auditButton)
        appAuditContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        auditCard.addView(appAuditContainer)
        content.addView(auditCard)

        val limitation = card()
        limitation.addView(label("LIMITATIONS & PLAY POLICY"))
        val limitationText = body("Installed-app inventory is sensitive information under Google Play policy. This build intentionally does not request QUERY_ALL_PACKAGES, so Android may provide only a limited visible-app set on Android 11+. If a future version needs broad app visibility, that use must be justified as core functionality and declared to Google Play.\n\nAccessibility services, overlays, developer options, emulator indicators, and alternate installers are review signals—not proof of malware or compromise.")
        limitation.addView(limitationText)
        content.addView(limitation)

        lastScanView = body("Last scan: --")
        content.addView(lastScanView)

        val scroll = ScrollView(this).apply { addView(content) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun runScan() {
        postureView.text = "Scanning device…"
        scanExecutor.execute {
            val result = SecurityScanner.scan(this, includeAppAudit = false)
            runOnUiThread {
                latest = result
                render(result)
            }
        }
    }

    private fun render(result: ScanResult) {
        scoreView.text = result.score.toString()
        postureView.text = when {
            result.score >= 90 -> "GOOD • no major local risk indicators detected"
            result.score >= 70 -> "REVIEW • one or more local risk indicators detected"
            else -> "ELEVATED RISK • significant local risk indicators detected"
        }
        summaryView.text = "Risk indicators: ${result.riskCount} • Review signals: ${result.reviewCount} • Critical: ${result.criticalCount} • Scan: ${result.scanDurationMs} ms"

        checksContainer.removeAllViews()
        result.checks.forEach { check ->
            checksContainer.addView(checkCard(check))
        }

        lastScanView.text = "Last scan: ${DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(result.timestamp))}"
    }

    private fun runAppAuditWithDisclosure() {
        AlertDialog.Builder(this)
            .setTitle("AegisScan app audit")
            .setMessage("AegisScan will inspect the application information Android makes visible to it, including package names, requested permissions, accessibility-service state, debug flags, and reported install sources. This processing stays on this device; AegisScan does not upload the results.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Run audit") { _, _ -> runAppAudit() }
            .show()
    }

    private fun runAppAudit() {
        appAuditSummary.text = "Scanning visible applications…"
        auditExecutor.execute {
            val risks = runCatching { com.aegisscan.app.security.InstalledAppAnalyzer.scan(this) }
                .getOrDefault(emptyList())
            runOnUiThread {
                val result = latest ?: return@runOnUiThread
                val updated = result.copy(appRisks = risks)
                latest = updated
                appAuditSummary.text = if (risks.isEmpty()) {
                    "No app review signals were found in the applications visible to Android/AegisScan. This is not proof that every installed app is safe."
                } else {
                    "${risks.size} app(s) have one or more review signals. None is automatically classified as malicious."
                }
                renderAppRisks(risks)
            }
        }
    }

    override fun onDestroy() {
        auditExecutor.shutdownNow()
        scanExecutor.shutdownNow()
        super.onDestroy()
    }

    private fun renderAppRisks(risks: List<AppRisk>) {
        appAuditContainer.removeAllViews()
        risks.take(25).forEach { risk ->
            val card = card()
            card.addView(title(risk.label))
            card.addView(body(risk.packageName))
            risk.riskSignals.forEach { signal ->
                card.addView(body("• $signal").apply { setPadding(0, dp(4), 0, 0) })
            }
            risk.installSource?.let { source ->
                card.addView(body("Install source: $source").apply { setPadding(0, dp(6), 0, 0) })
            }
            appAuditContainer.addView(card)
        }
        if (risks.size > 25) {
            appAuditContainer.addView(body("Showing the first 25 of ${risks.size} review-signal apps."))
        }
    }

    private fun checkCard(check: com.aegisscan.app.model.ScanCheck): LinearLayout {
        val item = card()
        item.addView(title(check.name))
        item.addView(body(check.detail).apply { setPadding(0, dp(6), 0, 0) })
        val status = when (check.severity) {
            Severity.CRITICAL -> "CRITICAL"
            Severity.WARNING -> "WARNING"
            Severity.REVIEW -> "REVIEW"
            Severity.INFO -> "INFO"
        }
        item.addView(label(status).apply { setPadding(0, dp(10), 0, 0) })
        check.evidence?.let {
            item.addView(body("Evidence: $it").apply { setPadding(0, dp(4), 0, 0) })
        }
        return item
    }

    private fun shareReport() {
        val result = latest ?: return
        val report = buildString {
            appendLine("AegisScan Security Posture Report")
            appendLine("Score: ${result.score}/100")
            appendLine("Risk indicators: ${result.riskCount}")
            appendLine("Review signals: ${result.reviewCount}")
            appendLine("Critical: ${result.criticalCount}")
            appendLine("Scan time: ${result.scanDurationMs} ms")
            appendLine()
            result.checks.forEach { check ->
                appendLine("${check.name}: ${check.detail}")
                check.evidence?.let { appendLine("Evidence: $it") }
                appendLine()
            }
            if (result.appRisks.isNotEmpty()) {
                appendLine("App audit review signals:")
                result.appRisks.forEach { app ->
                    appendLine("- ${app.label} (${app.packageName})")
                    app.riskSignals.forEach { appendLine("  - $it") }
                }
                appendLine()
            }
            appendLine("Important: AegisScan reports observable Android security posture signals. It does not prove a device is malware-free, spyware-free, or uncompromised.")
        }
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "AegisScan security report")
            putExtra(Intent.EXTRA_TEXT, report)
        }, "Share AegisScan report"))
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        setBackgroundColor(0xFF111827.toInt())
        layoutParams = LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            setMargins(0, 0, 0, dp(12))
        }
    }

    private fun label(value: String): TextView = TextView(this).apply {
        text = value
        textSize = 12f
        setTextColor(0xFFF43F5E.toInt())
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        letterSpacing = 0.05f
    }

    private fun title(value: String): TextView = TextView(this).apply {
        text = value
        textSize = 22f
        setTextColor(0xFFFFFFFF.toInt())
        setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun body(value: String): TextView = TextView(this).apply {
        text = value
        textSize = 14f
        setTextColor(0xFFAAB4C3.toInt())
        setLineSpacing(0f, 1.15f)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
