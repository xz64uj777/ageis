package com.aegisscan.app.security

import android.os.Build
import java.io.File

object RootDetector {
    private val suPaths = listOf(
        "/system/bin/su", "/system/xbin/su", "/sbin/su", "/system/su",
        "/system/bin/.ext/su", "/vendor/bin/su", "/data/local/su",
        "/data/local/bin/su", "/data/local/xbin/su"
    )

    data class Result(val risky: Boolean, val detail: String, val evidence: String)

    fun scan(): Result {
        val suPath = suPaths.firstOrNull { File(it).exists() }
        if (suPath != null) {
            return Result(
                risky = true,
                detail = "A known su executable exists at a standard location. This is a strong local root indicator, but it is not an absolute proof of full device compromise.",
                evidence = suPath
            )
        }

        val tags = Build.TAGS.orEmpty()
        if (tags.contains("test-keys", ignoreCase = true)) {
            return Result(
                risky = false,
                detail = "The build reports test-keys. This can occur on development or modified builds and is not proof of root access.",
                evidence = "ro.build.tags=$tags"
            )
        }

        return Result(
            risky = false,
            detail = "No common local su indicators were found. AegisScan cannot prove that the device is unrooted from this check alone.",
            evidence = "Checked ${suPaths.size} standard su locations."
        )
    }
}
