package com.aegisscan.app.security

import android.Manifest
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import com.aegisscan.app.model.AppRisk

object InstalledAppAnalyzer {
    private val interestingPermissions = linkedMapOf(
        Manifest.permission.SYSTEM_ALERT_WINDOW to "draw over other apps",
        Manifest.permission.REQUEST_INSTALL_PACKAGES to "request package installation",
        Manifest.permission.RECEIVE_SMS to "receive SMS",
        Manifest.permission.READ_SMS to "read SMS",
        Manifest.permission.SEND_SMS to "send SMS",
        Manifest.permission.READ_CALL_LOG to "read call log",
        Manifest.permission.WRITE_CALL_LOG to "write call log",
        Manifest.permission.READ_CONTACTS to "read contacts",
        Manifest.permission.RECORD_AUDIO to "microphone",
        Manifest.permission.CAMERA to "camera",
        Manifest.permission.ACCESS_FINE_LOCATION to "precise location",
        Manifest.permission.ACCESS_COARSE_LOCATION to "approximate location"
    )

    fun scan(context: Context): List<AppRisk> {
        val pm = context.packageManager
        val ownPackage = context.packageName
        val accessibilityPackages = enabledAccessibilityPackages(context)
        val packages = runCatching {
            @Suppress("DEPRECATION")
            pm.getInstalledPackages(PackageManager.GET_PERMISSIONS)
        }.getOrDefault(emptyList())

        return packages.asSequence()
            .filter { it.packageName != ownPackage }
            .mapNotNull { info ->
                val appInfo = info.applicationInfo ?: return@mapNotNull null
                if ((appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                    (appInfo.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0) {
                    return@mapNotNull null
                }

                val requested = info.requestedPermissions.orEmpty()
                val interesting = requested.mapNotNull { permission ->
                    interestingPermissions[permission]?.let { description ->
                        "$permission ($description)"
                    }
                }
                val accessibility = accessibilityPackages.contains(info.packageName)
                val debuggable = (appInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
                val overlay = requested.contains(Manifest.permission.SYSTEM_ALERT_WINDOW)
                val installSource = InstallSourceDetector.sourcePackage(context, info.packageName)

                val signals = buildList {
                    if (interesting.isNotEmpty()) add("Requests sensitive capability: ${interesting.size}")
                    if (accessibility) add("Accessibility service is enabled")
                    if (debuggable) add("App is marked debuggable")
                    if (overlay) add("Requests overlay capability")
                    if (!installSource.isNullOrBlank() && installSource !in commonInstallers) {
                        add("Install source is outside common Play/system installers")
                    }
                }

                if (signals.isEmpty()) return@mapNotNull null

                val label = runCatching { pm.getApplicationLabel(appInfo).toString() }
                    .getOrDefault(info.packageName)

                AppRisk(
                    packageName = info.packageName,
                    label = label,
                    riskSignals = signals,
                    requestedPermissions = interesting,
                    installSource = installSource,
                    debuggable = debuggable,
                    hasAccessibilityService = accessibility,
                    requestsOverlay = overlay
                )
            }
            .sortedWith(
                compareByDescending<AppRisk> { it.hasAccessibilityService }
                    .thenByDescending { it.requestedPermissions.size }
                    .thenByDescending { it.debuggable }
                    .thenBy { it.label.lowercase() }
            )
            .take(100)
            .toList()
    }

    private val commonInstallers = setOf(
        "com.android.vending",
        "com.google.android.packageinstaller",
        "com.google.android.permissioncontroller",
        "com.samsung.android.packageinstaller",
        "com.android.packageinstaller"
    )

    private fun enabledAccessibilityPackages(context: Context): Set<String> {
        val manager = context.getSystemService(android.view.accessibility.AccessibilityManager::class.java)
            ?: return emptySet()
        val services = runCatching {
            manager.getEnabledAccessibilityServiceList(android.accessibilityservice.AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
        }.getOrDefault(emptyList())
        return services.mapNotNull { it.resolveInfo?.serviceInfo?.packageName }.toSet()
    }
}
