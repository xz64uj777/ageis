package com.aegisscan.app.model

enum class Severity { INFO, REVIEW, WARNING, CRITICAL }

data class ScanCheck(
    val name: String,
    val detail: String,
    val risky: Boolean = false,
    val review: Boolean = false,
    val severity: Severity = when {
        risky && review -> Severity.WARNING
        risky -> Severity.WARNING
        review -> Severity.REVIEW
        else -> Severity.INFO
    },
    val deduction: Int = 0,
    val evidence: String? = null
)

data class AppRisk(
    val packageName: String,
    val label: String,
    val riskSignals: List<String>,
    val requestedPermissions: List<String>,
    val installSource: String?,
    val debuggable: Boolean,
    val hasAccessibilityService: Boolean,
    val requestsOverlay: Boolean
)

data class ScanResult(
    val checks: List<ScanCheck>,
    val appRisks: List<AppRisk>,
    val score: Int,
    val timestamp: Long,
    val scanDurationMs: Long
) {
    val riskCount: Int get() = checks.count { it.risky }
    val reviewCount: Int get() = checks.count { it.review } + appRisks.size
    val criticalCount: Int get() = checks.count { it.severity == Severity.CRITICAL }
}
