package com.aegisscan.app.security

import android.app.KeyguardManager
import android.content.Context
import android.os.Build
import android.os.PowerManager

object DeviceSecurityDetector {
    data class Result(val risky: Boolean, val detail: String, val evidence: String)

    fun lockScreen(context: Context): Result {
        val km = context.getSystemService(KeyguardManager::class.java)
            ?: return Result(false, "Lock-screen state could not be determined.", "KeyguardManager unavailable")
        return if (km.isDeviceSecure) {
            Result(false, "A secure lock screen is configured.", "KeyguardManager.isDeviceSecure=true")
        } else {
            Result(
                true,
                "No secure lock screen is configured. Use a PIN, password, or another supported secure lock method.",
                "KeyguardManager.isDeviceSecure=false"
            )
        }
    }

    fun encryption(): Result {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            Result(
                false,
                "Modern Android devices normally use file-based or full-disk encryption, but AegisScan cannot reliably attest the device's encryption state through a stable public API on every supported device.",
                "Android API ${Build.VERSION.SDK_INT}; no stable public attestation used"
            )
        } else {
            Result(
                false,
                "This Android version does not expose a reliable public encryption-state check used by AegisScan.",
                "Android API ${Build.VERSION.SDK_INT}"
            )
        }
    }

    fun powerSaver(context: Context): Result {
        val pm = context.getSystemService(PowerManager::class.java)
            ?: return Result(false, "Power-saver state could not be determined.", "PowerManager unavailable")
        val on = runCatching { pm.isPowerSaveMode }.getOrDefault(false)
        return Result(
            false,
            if (on) "Battery saver is currently enabled." else "Battery saver is currently disabled.",
            "PowerManager.isPowerSaveMode=$on"
        )
    }
}
