package com.aegisscan.app.security

import android.content.Context
import android.content.pm.ApplicationInfo
import android.os.SystemClock
import com.aegisscan.app.model.ScanCheck
import com.aegisscan.app.model.ScanResult
import com.aegisscan.app.model.Severity

object SecurityScanner {
    fun scan(context: Context, includeAppAudit: Boolean = false): ScanResult {
        val start = SystemClock.elapsedRealtime()
        val checks = mutableListOf<ScanCheck>()

        val root = RootDetector.scan()
        checks += ScanCheck(
            name = "Root indicators",
            detail = root.detail,
            risky = root.risky,
            severity = if (root.risky) Severity.CRITICAL else Severity.INFO,
            deduction = if (root.risky) 35 else 0,
            evidence = root.evidence
        )

        val debugger = DebuggerDetector.isDebuggerConnected()
        checks += ScanCheck(
            name = "Debugger attached",
            detail = DebuggerDetector.detail(),
            risky = debugger,
            severity = if (debugger) Severity.WARNING else Severity.INFO,
            deduction = if (debugger) 20 else 0,
            evidence = "android.os.Debug.isDebuggerConnected()"
        )

        val adb = UsbDebuggingDetector.isEnabled(context)
        checks += ScanCheck(
            name = "USB debugging (ADB)",
            detail = UsbDebuggingDetector.detail(context),
            risky = adb,
            severity = if (adb) Severity.WARNING else Severity.INFO,
            deduction = if (adb) 10 else 0,
            evidence = "Settings.Global.ADB_ENABLED"
        )

        val dev = DeveloperOptionsDetector.isEnabled(context)
        checks += ScanCheck(
            name = "Developer options",
            detail = DeveloperOptionsDetector.detail(context),
            review = dev,
            severity = if (dev) Severity.REVIEW else Severity.INFO,
            evidence = "Settings.Global.DEVELOPMENT_SETTINGS_ENABLED"
        )

        val emulator = EmulatorDetector.isLikelyEmulator()
        checks += ScanCheck(
            name = "Emulator profile",
            detail = EmulatorDetector.detail(),
            review = emulator,
            severity = if (emulator) Severity.REVIEW else Severity.INFO,
            evidence = if (emulator) "Common emulator Build.* indicators matched." else "No common emulator indicators matched."
        )

        val buildInfo = BuildInfoDetector.summary(context)
        checks += ScanCheck(
            name = "Android build security info",
            detail = "${buildInfo.first}.\n${buildInfo.second}",
            severity = Severity.INFO,
            evidence = "Build.VERSION / package signing certificate"
        )

        val network = NetworkDetector.state(context)
        checks += ScanCheck(
            name = "Network",
            detail = "Transport: ${network.transport}. VPN: ${if (network.vpn) "active" else "not detected"}. Validated: ${if (network.validated) "yes" else "no"}. AegisScan does not inspect or transmit network traffic.",
            severity = Severity.INFO,
            evidence = "ConnectivityManager / NetworkCapabilities"
        )

        val lock = DeviceSecurityDetector.lockScreen(context)
        checks += ScanCheck(
            name = "Secure lock screen",
            detail = lock.detail,
            risky = lock.risky,
            severity = if (lock.risky) Severity.WARNING else Severity.INFO,
            deduction = if (lock.risky) 15 else 0,
            evidence = lock.evidence
        )

        val encryption = DeviceSecurityDetector.encryption()
        checks += ScanCheck(
            name = "Storage encryption",
            detail = encryption.detail,
            risky = encryption.risky,
            severity = if (encryption.risky) Severity.WARNING else Severity.INFO,
            deduction = if (encryption.risky) 15 else 0,
            evidence = encryption.evidence
        )

        val powerSaver = DeviceSecurityDetector.powerSaver(context)
        checks += ScanCheck(
            name = "Power state",
            detail = powerSaver.detail,
            severity = Severity.INFO,
            evidence = powerSaver.evidence
        )

        val playInstall = PlayStoreDetector.isProbablyPlayInstalled(context)
        checks += ScanCheck(
            name = "AegisScan install source",
            detail = InstallSourceDetector.detail(context),
            review = playInstall == false,
            severity = when (playInstall) {
                true, null -> Severity.INFO
                false -> Severity.REVIEW
            },
            evidence = "PackageManager.getInstallSourceInfo() when available"
        )

        val debugBuild = (context.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
        checks += ScanCheck(
            name = "AegisScan build",
            detail = if (debugBuild) {
                "This installed AegisScan build is debuggable. Use a signed release build for production distribution."
            } else {
                "This installed AegisScan build is not marked debuggable."
            },
            risky = debugBuild,
            severity = if (debugBuild) Severity.WARNING else Severity.INFO,
            deduction = if (debugBuild) 10 else 0,
            evidence = "ApplicationInfo.FLAG_DEBUGGABLE"
        )

        val appRisks = if (includeAppAudit) {
            runCatching { InstalledAppAnalyzer.scan(context) }.getOrDefault(emptyList())
        } else {
            emptyList()
        }
        val score = (100 - checks.sumOf { it.deduction }).coerceIn(0, 100)

        return ScanResult(
            checks = checks,
            appRisks = appRisks,
            score = score,
            timestamp = System.currentTimeMillis(),
            scanDurationMs = SystemClock.elapsedRealtime() - start
        )
    }
}
