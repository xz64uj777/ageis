package com.aegisscan.app.security

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities

object NetworkDetector {
    data class Result(val transport: String, val vpn: Boolean, val validated: Boolean)

    fun state(context: Context): Result {
        val cm = context.getSystemService(ConnectivityManager::class.java)
            ?: return Result("Unknown", false, false)
        val network = cm.activeNetwork ?: return Result("Offline", false, false)
        val caps = cm.getNetworkCapabilities(network) ?: return Result("Unknown", false, false)
        val transport = when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Cellular"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "Other"
        }
        return Result(
            transport = transport,
            vpn = caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN),
            validated = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        )
    }
}
