package com.aegisscan.app.security

import android.content.Context

object PlayStoreDetector {
    fun isProbablyPlayInstalled(context: Context): Boolean? =
        InstallSourceDetector.isProbablyPlayInstalled(context)
}
