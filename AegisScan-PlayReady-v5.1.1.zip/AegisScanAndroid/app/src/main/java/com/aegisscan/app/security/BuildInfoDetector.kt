package com.aegisscan.app.security

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import java.security.MessageDigest

object BuildInfoDetector {
    fun summary(context: Context): Pair<String, String> {
        val os = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"
        val patch = Build.VERSION.SECURITY_PATCH.ifBlank { "unknown" }
        val signer = signingSha256(context)
        return os to "Security patch: $patch\nAegisScan signer SHA-256: $signer"
    }

    private fun signingSha256(context: Context): String {
        return runCatching {
            val pm = context.packageManager
            val signatures = if (Build.VERSION.SDK_INT >= 28) {
                val info = pm.getPackageInfo(context.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
                info.signingInfo.apkContentsSigners
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(context.packageName, PackageManager.GET_SIGNATURES).signatures
            }
            val cert = signatures.firstOrNull() ?: return "unknown"
            MessageDigest.getInstance("SHA-256").digest(cert.toByteArray())
                .joinToString(":") { "%02X".format(it) }
        }.getOrDefault("unknown")
    }
}
