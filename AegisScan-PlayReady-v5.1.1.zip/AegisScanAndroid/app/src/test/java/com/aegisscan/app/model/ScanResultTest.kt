package com.aegisscan.app.model

import org.junit.Assert.assertEquals
import org.junit.Test

class ScanResultTest {
    @Test
    fun countsRiskAndReviewSignalsSeparately() {
        val checks = listOf(
            ScanCheck("root", "signal", risky = true, severity = Severity.CRITICAL, deduction = 35),
            ScanCheck("developer options", "context", review = true, severity = Severity.REVIEW),
            ScanCheck("network", "info")
        )
        val apps = listOf(
            AppRisk("example.app", "Example", listOf("enabled accessibility service"), emptyList(), null, false, true, false)
        )
        val result = ScanResult(checks, apps, 65, 1L, 3L)

        assertEquals(1, result.riskCount)
        assertEquals(2, result.reviewCount)
        assertEquals(1, result.criticalCount)
    }
}
