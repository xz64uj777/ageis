# Gradle tooling

GitHub Actions installs Gradle 8.11.1 directly, so a Gradle wrapper JAR is not required in the repository.

AndroidIDE may generate the standard wrapper locally when the project is opened. Do not commit a machine-specific SDK path.
