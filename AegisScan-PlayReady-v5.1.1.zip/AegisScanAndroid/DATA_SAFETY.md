# Play Console Data Safety — development notes

Re-check the final signed build before answering the Play Console form.

Current implementation:
- No account creation.
- No internet permission.
- No scan-result upload.
- No advertising SDK.
- No analytics SDK.
- No microphone/camera/location/contacts/SMS collection by AegisScan.
- Optional local app-audit processing may access package/application metadata and requested permissions exposed by Android. It is not transmitted off-device by the current implementation.
- Network information is used only to display local transport/VPN/validated state.

The installed-app inventory is treated as sensitive information under Google Play policy. The current version intentionally does not request QUERY_ALL_PACKAGES. If broad package visibility is added later, the Play Console declaration and Data Safety statements must be updated accurately.
