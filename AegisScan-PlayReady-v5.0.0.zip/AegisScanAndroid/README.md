# AegisScan

Native Android security posture monitor.

## What AegisScan actually checks
- Common local root indicators (heuristic)
- Whether a debugger is attached to the AegisScan process
- USB debugging / ADB setting
- Developer options status (context only)
- Common emulator profile indicators (context only)
- Current network transport
- Android-reported app install source
- Whether the installed AegisScan build is debuggable

## What it does NOT claim
AegisScan does **not** prove that a device is malware-free, spyware-free, uncompromised, or protected from remote control. It does not currently perform antivirus scanning, full installed-app malware analysis, Play Protect verification, or hardware-backed device attestation.

## Scoring policy
Only checks with a defined security impact affect the posture score. Developer options, emulator detection, and network state are displayed as context and do not automatically lower the score. Root indicators are heuristic and explicitly described as such.

## Play Store readiness
The project targets Android 16 (API 36), which is the Google Play target requirement for new apps and updates starting August 31, 2026. See Google's current requirements: https://developer.android.com/google/play/requirements/target-sdk

Play Integrity is intentionally not faked or partially implemented. A production integration needs a Google Play Console/Cloud setup plus backend verification of integrity tokens.

## Build
Use AndroidIDE or Android Studio with Android SDK 36 and a JDK 17 toolchain. The project uses Android Gradle Plugin 8.10.1 and Gradle 8.11.1.

The included GitHub Actions workflow builds a debug APK and a release bundle task can be added after signing configuration is established.

## Development vs production
The debug variant is intentionally debuggable and has the `.debug` application-id suffix. It should not be used as the Play Store upload. The release variant is non-debuggable and must be signed before publication.
