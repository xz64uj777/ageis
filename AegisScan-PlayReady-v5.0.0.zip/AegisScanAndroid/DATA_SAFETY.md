# Play Console Data Safety — Development Notes

Based on the current source:

- No account creation.
- No user content uploaded.
- No location collection.
- No contacts collection.
- No microphone/camera collection.
- No advertising SDK.
- No analytics SDK.
- No remote scan-result transmission.
- ACCESS_NETWORK_STATE is used only to display the current network transport; it is not used to collect browsing history or transmit network data.

This file is not a substitute for the Play Console form. Re-check the final signed build and all third-party SDKs before declaring the app's data practices.
