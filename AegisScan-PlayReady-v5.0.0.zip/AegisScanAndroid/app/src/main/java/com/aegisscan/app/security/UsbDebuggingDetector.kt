package com.aegisscan.app.security

import android.content.Context
import android.os.Build
import android.provider.Settings

object UsbDebuggingDetector {
    fun isEnabled(context: Context): Boolean = runCatching {
        val key = if (Build.VERSION.SDK_INT >= 17) Settings.Global.ADB_ENABLED else "adb_enabled"
        Settings.Global.getInt(context.contentResolver, key, 0) == 1
    }.getOrDefault(false)

    fun detail(context: Context): String = if (isEnabled(context)) {
        "USB debugging (ADB) is enabled. Keep it disabled when you do not need it."
    } else {
        "USB debugging (ADB) is disabled."
    }
}
