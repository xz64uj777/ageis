package com.aegisscan.app.security

import android.content.Context
import android.os.Build

object InstallSourceDetector {
    fun detail(context: Context): String {
        if (Build.VERSION.SDK_INT < 30) return "Install source is not available from the supported API on this device."
        val source = runCatching {
            context.packageManager.getInstallSourceInfo(context.packageName).installingPackageName
        }.getOrNull()

        return when (source) {
            "com.android.vending" -> "Installed by Google Play."
            null, "" -> "Install source could not be determined."
            else -> "Installing package reported by Android: $source"
        }
    }
}
