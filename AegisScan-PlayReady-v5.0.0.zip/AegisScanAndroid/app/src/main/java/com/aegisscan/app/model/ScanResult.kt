package com.aegisscan.app.model

enum class Severity { INFO, WARNING, CRITICAL }

data class ScanCheck(
    val name: String,
    val detail: String,
    val risky: Boolean,
    val severity: Severity = when {
        !risky -> Severity.INFO
        else -> Severity.WARNING
    },
    val deduction: Int = 0,
    val evidence: String? = null
)

data class ScanResult(
    val checks: List<ScanCheck>,
    val score: Int,
    val timestamp: Long,
    val scanDurationMs: Long
) {
    val riskCount: Int get() = checks.count { it.risky }
    val warningCount: Int get() = checks.count { it.risky && it.severity == Severity.WARNING }
    val criticalCount: Int get() = checks.count { it.risky && it.severity == Severity.CRITICAL }
}
