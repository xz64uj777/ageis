package com.aegisscan.app.security

import android.os.Debug

object DebuggerDetector {
    fun isDebuggerConnected(): Boolean = Debug.isDebuggerConnected()

    fun detail(): String = if (isDebuggerConnected()) {
        "A debugger is currently attached to this application process."
    } else {
        "No debugger is currently attached to this application process."
    }
}
