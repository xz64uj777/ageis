package com.aegisscan.app

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.aegisscan.app.model.ScanResult
import com.aegisscan.app.model.Severity
import com.aegisscan.app.security.SecurityScanner
import java.text.DateFormat
import java.util.Date

class MainActivity : AppCompatActivity() {
    private lateinit var scoreView: TextView
    private lateinit var postureView: TextView
    private lateinit var summaryView: TextView
    private lateinit var checksContainer: LinearLayout
    private lateinit var lastScanView: TextView
    private var latest: ScanResult? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        runScan()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF070B14.toInt())
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(30))
        }

        content.addView(label("AEGISSCAN"))
        content.addView(title("Android Security Monitor"))
        content.addView(body("Local security posture checks. AegisScan does not claim to prove that a device is malware-free or uncompromised."))

        val scoreCard = card()
        scoreCard.addView(label("SECURITY POSTURE"))
        scoreView = title("--").apply {
            textSize = 52f
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, dp(8), 0, 0)
        }
        scoreCard.addView(scoreView)
        postureView = body("Scanning…").apply {
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, dp(2), 0, dp(4))
        }
        scoreCard.addView(postureView)
        content.addView(scoreCard)

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        val scanButton = Button(this).apply {
            text = "SCAN"
            isAllCaps = false
            setOnClickListener { runScan() }
        }
        actions.addView(scanButton, LinearLayout.LayoutParams(0, dp(52), 1f).apply { setMargins(0, 0, dp(6), dp(12)) })
        val shareButton = Button(this).apply {
            text = "SHARE REPORT"
            isAllCaps = false
            setOnClickListener { shareReport() }
        }
        actions.addView(shareButton, LinearLayout.LayoutParams(0, dp(52), 1f).apply { setMargins(dp(6), 0, 0, dp(12)) })
        content.addView(actions)

        summaryView = body("Risk indicators: 0")
        content.addView(summaryView)

        val note = card()
        note.addView(label("IMPORTANT LIMITATION"))
        note.addView(body("Root checks are heuristic. Developer options and emulator detection are context signals, not proof of an attack. Play Protect, malware detection, remote-control detection, and hardware-backed device integrity require additional platform services and/or a backend. This app does not currently claim those capabilities."))
        content.addView(note)

        checksContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(checksContainer)

        lastScanView = body("Last scan: --")
        content.addView(lastScanView)

        val scroll = ScrollView(this).apply { addView(content) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun runScan() {
        val result = SecurityScanner.scan(this)
        latest = result
        render(result)
    }

    private fun render(result: ScanResult) {
        scoreView.text = result.score.toString()
        postureView.text = when {
            result.score >= 90 -> "GOOD • no major local risk indicators detected"
            result.score >= 70 -> "REVIEW • one or more local risk indicators detected"
            else -> "ELEVATED RISK • significant local risk indicators detected"
        }
        summaryView.text = "Risk indicators: ${result.riskCount} • Critical: ${result.criticalCount} • Scan: ${result.scanDurationMs} ms"

        checksContainer.removeAllViews()
        result.checks.forEach { check ->
            val item = card()
            item.addView(title(check.name))
            item.addView(body(check.detail).apply { setPadding(0, dp(6), 0, 0) })

            val status = when (check.severity) {
                Severity.CRITICAL -> "CRITICAL"
                Severity.WARNING -> if (check.risky) "REVIEW" else "INFO"
                Severity.INFO -> "INFO"
            }
            item.addView(label(status).apply { setPadding(0, dp(10), 0, 0) })
            check.evidence?.let {
                item.addView(body("Evidence: $it").apply { setPadding(0, dp(4), 0, 0) })
            }
            checksContainer.addView(item)
        }

        lastScanView.text = "Last scan: ${DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(result.timestamp))}"
    }

    private fun shareReport() {
        val result = latest ?: return
        val report = buildString {
            appendLine("AegisScan Security Posture")
            appendLine("Score: ${result.score}/100")
            appendLine("Risk indicators: ${result.riskCount}")
            appendLine("Critical: ${result.criticalCount}")
            appendLine("Scan time: ${result.scanDurationMs} ms")
            appendLine()
            result.checks.forEach { check ->
                appendLine("${check.name}: ${check.detail}")
                check.evidence?.let { appendLine("Evidence: $it") }
                appendLine()
            }
            appendLine("Important: AegisScan provides local heuristic checks. It does not prove a device is malware-free, spyware-free, or uncompromised.")
        }
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "AegisScan security report")
            putExtra(Intent.EXTRA_TEXT, report)
        }, "Share AegisScan report"))
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        setBackgroundColor(0xFF111827.toInt())
        layoutParams = LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            setMargins(0, 0, 0, dp(12))
        }
    }

    private fun label(value: String): TextView = TextView(this).apply {
        text = value
        textSize = 12f
        setTextColor(0xFFF43F5E.toInt())
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        letterSpacing = 0.05f
    }

    private fun title(value: String): TextView = TextView(this).apply {
        text = value
        textSize = 22f
        setTextColor(0xFFFFFFFF.toInt())
        setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun body(value: String): TextView = TextView(this).apply {
        text = value
        textSize = 14f
        setTextColor(0xFFAAB4C3.toInt())
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
