package com.aegisscan.app.security

import android.content.Context
import android.content.pm.ApplicationInfo
import android.os.SystemClock
import com.aegisscan.app.model.ScanCheck
import com.aegisscan.app.model.ScanResult
import com.aegisscan.app.model.Severity

object SecurityScanner {
    fun scan(context: Context): ScanResult {
        val start = SystemClock.elapsedRealtime()
        val checks = mutableListOf<ScanCheck>()

        val root = RootDetector.scan()
        checks += ScanCheck(
            name = "Root indicators",
            detail = root.detail,
            risky = root.risky,
            severity = if (root.risky) Severity.CRITICAL else Severity.INFO,
            deduction = if (root.risky) 35 else 0,
            evidence = root.evidence
        )

        val debugger = DebuggerDetector.isDebuggerConnected()
        checks += ScanCheck(
            name = "Debugger attached",
            detail = DebuggerDetector.detail(),
            risky = debugger,
            severity = if (debugger) Severity.WARNING else Severity.INFO,
            deduction = if (debugger) 20 else 0,
            evidence = "android.os.Debug.isDebuggerConnected()"
        )

        val adb = UsbDebuggingDetector.isEnabled(context)
        checks += ScanCheck(
            name = "USB debugging (ADB)",
            detail = UsbDebuggingDetector.detail(context),
            risky = adb,
            severity = if (adb) Severity.WARNING else Severity.INFO,
            deduction = if (adb) 15 else 0,
            evidence = "Settings.Global.ADB_ENABLED"
        )

        val dev = DeveloperOptionsDetector.isEnabled(context)
        checks += ScanCheck(
            name = "Developer options",
            detail = DeveloperOptionsDetector.detail(context),
            risky = false,
            severity = Severity.INFO,
            evidence = "Settings.Global.DEVELOPMENT_SETTINGS_ENABLED"
        )

        val emulator = EmulatorDetector.isLikelyEmulator()
        checks += ScanCheck(
            name = "Emulator profile",
            detail = EmulatorDetector.detail(),
            risky = false,
            severity = Severity.INFO,
            evidence = if (emulator) "Common emulator Build.* indicators matched." else "No common emulator indicators matched."
        )

        checks += ScanCheck(
            name = "Network",
            detail = "Current network transport: ${NetworkDetector.transport(context)}.",
            risky = false,
            severity = Severity.INFO,
            evidence = "ConnectivityManager / NetworkCapabilities"
        )

        checks += ScanCheck(
            name = "App install source",
            detail = InstallSourceDetector.detail(context),
            risky = false,
            severity = Severity.INFO,
            evidence = "PackageManager.getInstallSourceInfo()"
        )

        val debugBuild = (context.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
        checks += ScanCheck(
            name = "App build",
            detail = if (debugBuild) {
                "This installed build is debuggable. Use a signed release build for production distribution."
            } else {
                "This installed build is not marked debuggable."
            },
            risky = debugBuild,
            severity = if (debugBuild) Severity.WARNING else Severity.INFO,
            deduction = if (debugBuild) 10 else 0,
            evidence = "ApplicationInfo.FLAG_DEBUGGABLE"
        )

        val score = (100 - checks.sumOf { it.deduction }).coerceIn(0, 100)
        return ScanResult(
            checks = checks,
            score = score,
            timestamp = System.currentTimeMillis(),
            scanDurationMs = SystemClock.elapsedRealtime() - start
        )
    }
}
