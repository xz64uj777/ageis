package com.aegisscan.app.security

import android.os.Build
import java.io.File

object RootDetector {
    private val suPaths = listOf(
        "/system/bin/su", "/system/xbin/su", "/sbin/su", "/system/su",
        "/system/bin/.ext/su", "/vendor/bin/su", "/data/local/su",
        "/data/local/bin/su", "/data/local/xbin/su"
    )

    data class Result(val risky: Boolean, val detail: String, val evidence: String)

    fun scan(): Result {
        val suPath = suPaths.firstOrNull { File(it).exists() }
        if (suPath != null) {
            return Result(
                risky = true,
                detail = "A known su executable exists at a standard location.",
                evidence = suPath
            )
        }

        val tags = Build.TAGS.orEmpty()
        if (tags.contains("test-keys", ignoreCase = true)) {
            return Result(
                risky = false,
                detail = "The build reports test-keys. This can indicate a development or modified build, but does not prove root access.",
                evidence = "ro.build.tags=$tags"
            )
        }

        return Result(
            risky = false,
            detail = "No common local root indicators were found. This does not prove the device is unrooted.",
            evidence = "Checked ${suPaths.size} standard su locations."
        )
    }
}
