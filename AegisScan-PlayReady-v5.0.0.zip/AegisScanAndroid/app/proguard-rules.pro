# AegisScan — keep WebView bridge if extended later
-keepclassmembers class com.aegisscan.app.MainActivity {
    @android.webkit.JavascriptInterface <methods>;
}
