# Play Store readiness checklist

## Current technical posture
- Native Kotlin Android app; no WebView.
- Target/compile SDK 36.
- Release build is non-debuggable and uses code/resource shrinking.
- No microphone, camera, contacts, SMS, location, accessibility, or notification permissions.
- No `INTERNET` permission in the manifest.
- Cleartext traffic is explicitly disabled.
- No analytics or advertising SDK.
- Debug build is separated with the `.debug` application ID suffix.

## Still required before production submission
- Generate a production signing key and configure release signing securely.
- Build and test a signed AAB on a physical device.
- Complete the Play Console Data safety form from the final signed build.
- Prepare an account/developer profile and store listing assets.
- Add a final public privacy-policy URL and ensure it matches the shipped behavior.
- Decide whether to add Play Integrity. If added, use Google's documented backend verification flow; do not treat a locally generated token as proof of integrity.
- Test on multiple physical Android versions and manufacturers.
- Review all dependencies and their transitive dependencies before release.

## Claims to avoid
Do not advertise AegisScan as an antivirus, spyware detector, malware detector, remote-hacker detector, or proof of a secure device unless those capabilities are actually implemented and validated.
