# AegisScan Privacy Notice (Draft)

AegisScan is designed to perform device-security posture checks locally on the device.

Current implementation:
- Does not request microphone, camera, contacts, SMS, location, phone, accessibility, or notification access.
- Does not send scan results to an AegisScan server.
- Uses Android system APIs to read local security/settings information needed for the displayed checks.
- Stores no account profile and no remote telemetry in the current implementation.

This notice is a development draft and must be reviewed before publication. If a future version adds analytics, cloud scanning, Play Integrity backend verification, crash reporting, or other data processing, this notice and the Play Console Data safety declaration must be updated before release.
